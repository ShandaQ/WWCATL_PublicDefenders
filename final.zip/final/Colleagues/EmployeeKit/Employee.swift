
import Foundation

public struct Employee: JSONDecodable {
  public let objectId: String
  public let department: String
  public let weight: String
  public let name: String
  public let height: String
  public let title: String
  public let skills: [String]
  
  public init(json: [NSObject: AnyObject]) throws {
    guard let objectId = json["objectId"] as? String else {
      throw JSONDecodingError.MissingAttribute("objectId")
    }
    guard let department = json["department"] as? String else {
      throw JSONDecodingError.MissingAttribute("department")
    }
    guard let weight = json["weight"] as? String else {
      throw JSONDecodingError.MissingAttribute("weight")
    }
    guard let name = json["name"] as? String else {
      throw JSONDecodingError.MissingAttribute("name")
    }
    guard let height = json["height"] as? String else {
      throw JSONDecodingError.MissingAttribute("height")
    }
    guard let title = json["title"] as? String else {
      throw JSONDecodingError.MissingAttribute("title")
    }
    guard let skills = json["skills"] as? [String] else {
      throw JSONDecodingError.MissingAttribute("skills")
    }
    
    self.objectId = objectId
    self.department = department
    self.weight = weight
    self.name = name
    self.height = height
    self.title = title
    self.skills = skills
  }
  
  public func loadPicture() -> UIImage {
    let splits = name.componentsSeparatedByString(" ")
    if let filename = splits.first {
      return UIImage(named: filename + ".jpg", inBundle: FileHelper.bundle, compatibleWithTraitCollection: nil) ?? UIImage()
    } else {
      return UIImage()
    }
  }
  
  public func loadSmallPicture() -> UIImage {
    let fullImage = loadPicture()
    let size = CGSize(width: 40, height: 40)
    UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
    fullImage.drawInRect(CGRect(x: 0, y: 0, width: size.width, height: size.height))
    fullImage
    let smallImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    return smallImage
  }
  
}