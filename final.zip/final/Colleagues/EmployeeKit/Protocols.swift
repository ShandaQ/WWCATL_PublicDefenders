

import Foundation

public enum JSONDecodingError: ErrorType {
  case MissingAttribute(String)
}

public protocol JSONDecodable {
  init(json: [NSObject: AnyObject]) throws
}