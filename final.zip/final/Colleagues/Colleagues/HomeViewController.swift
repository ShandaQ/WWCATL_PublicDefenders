//
//  HomeViewController.swift
//  Colleagues
//
//  Created by Ayanna Kosoko on 7/30/16.
//  Copyright © 2016 Razeware LLC. All rights reserved.
//

import UIKit
import EmployeeKit

class HomeViewController: UIViewController {
  
  @IBOutlet weak var submitButton: UIButton!
    
    
    @IBAction func submitbuttonTapped(sender: AnyObject) {
    }
  
  @IBOutlet weak var logoImage: UIImageView!
  
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
  
}

}




