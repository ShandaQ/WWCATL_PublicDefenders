
import UIKit
import EmployeeKit

class EmployeeViewController: UIViewController {
  
  @IBOutlet weak var pictureImageView: UIImageView!
  @IBOutlet weak var nameLabel: UILabel!
  @IBOutlet weak var departmentLabel: UILabel!
  @IBOutlet weak var badgeIDLabel: UILabel!
  @IBOutlet weak var heightLabel: UILabel!
  @IBOutlet weak var weightLabel: UILabel!
  @IBOutlet weak var moreLabel: UILabel!
  
  @IBOutlet weak var otherEmployeesLabel: UILabel!
  
  @IBOutlet weak var sameDepartmentContainerView: UIView!
  @IBOutlet weak var submitButtonTapped: UIButton!
  
  var employee: Employee!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    pictureImageView.image = employee.loadPicture()
    nameLabel.text = employee.name
    departmentLabel.text = employee.department
    badgeIDLabel.text = employee.title
    heightLabel.text = employee.height
    weightLabel.text = employee.weight
    moreLabel.text = employee.skills.joinWithSeparator(", ")
    otherEmployeesLabel.text = "Complete report for Officer \(employee.name)"
    let activity = employee.userActivity
    
    switch Setting.searchIndexingPreference {
    case .Disabled:
      activity.eligibleForSearch = false
    case .ViewedRecords:
      activity.eligibleForSearch = true
    }
    
    userActivity = activity

  }
  
  override func updateUserActivityState(activity: NSUserActivity) {
    activity.addUserInfoEntriesFromDictionary(
      employee.userActivityUserInfo)
  }

  
  override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    if let destination = segue.destinationViewController as? EmployeeListViewController
      where segue.identifier == "EmployeeListEmbedSegue" {
        destination.filterEmployees { employee -> Bool in
          employee.department == self.employee.department && employee.objectId != self.employee.objectId
      }
    }
  }
}
